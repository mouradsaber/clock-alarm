@echo off
setlocal enabledelayedexpansion
title Clock Pro — Setup & Build

echo.
echo  =====================================================
echo    CLOCK PRO  ^|  Desktop App Setup
echo  =====================================================
echo.

:: ── 1. Check Node.js ────────────────────────────────────
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Node.js not found.
    echo.
    echo  Please install Node.js first:
    echo  https://nodejs.org  ^(LTS version^)
    echo.
    echo  After installing, run this script again.
    echo.
    pause
    start https://nodejs.org
    exit /b 1
)

for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo  [OK] Node.js %NODE_VER% found.

:: ── 2. Install dependencies ──────────────────────────────
echo.
echo  [>>] Installing dependencies (this downloads Electron ~100MB)...
echo       This may take 2-5 minutes on first run.
echo.
call npm install --legacy-peer-deps
if %errorlevel% neq 0 (
    echo.
    echo  [!] npm install failed. Check your internet connection.
    pause
    exit /b 1
)
echo.
echo  [OK] Dependencies installed.

:: ── 3. Build Windows executables ────────────────────────
echo.
echo  [>>] Building Windows executables...
echo       Output will be in the  dist\  folder.
echo.
call npx electron-builder --win --x64
if %errorlevel% neq 0 (
    echo.
    echo  [!] Build failed. Try running:  run-dev.bat  instead.
    pause
    exit /b 1
)

:: ── 4. Done ──────────────────────────────────────────────
echo.
echo  =====================================================
echo    BUILD COMPLETE
echo  =====================================================
echo.
echo  Files created in  dist\ folder:
echo.
dir /b dist\ 2>nul
echo.
echo  - ClockPro-Portable.exe  ^(run anywhere, no install^)
echo  - ClockPro-Setup.exe     ^(installs to your PC^)
echo.
echo  Double-click either .exe to launch Clock Pro!
echo.
pause
explorer dist\
