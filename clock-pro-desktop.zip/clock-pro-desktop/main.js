const { app, BrowserWindow, ipcMain, nativeTheme, Tray, Menu, shell } = require('electron');
const path = require('path');

let mainWindow;
let tray;

// Fix for high-DPI scaling
app.commandLine.appendSwitch('high-dpi-support', '1');
app.commandLine.appendSwitch('force-device-scale-factor', '1');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 460,
    height: 900,
    minWidth: 400,
    minHeight: 680,
    maxWidth: 560,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
    title: 'Clock Pro',
    backgroundColor: '#030509',
    show: false,
    frame: false,           // Custom frameless window
    titleBarStyle: 'hidden',
    resizable: true,
    center: true,
  });

  mainWindow.loadFile('index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // Allow external links to open in browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// IPC handlers for custom window controls
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => mainWindow?.close());
ipcMain.on('window-is-maximized', (e) => {
  e.returnValue = mainWindow?.isMaximized() ?? false;
});

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
