@echo off
title Clock Pro — Dev Mode

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js not found. Please install from https://nodejs.org
    pause
    exit /b 1
)

if not exist "node_modules\electron" (
    echo Installing dependencies...
    call npm install --legacy-peer-deps
)

echo Starting Clock Pro...
npx electron .
