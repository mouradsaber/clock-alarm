# Clock Pro — Windows Desktop App

A luxury clock, alarm, timer, and interval training app for Windows,
built with Electron.

## Quick Start

### Option 1 — Run instantly (dev mode)
1. Install **Node.js** from https://nodejs.org (LTS version)
2. Double-click **`run-dev.bat`**
   - First launch downloads Electron (~100 MB) automatically
   - App opens in a native window

### Option 2 — Build a standalone .exe
1. Install **Node.js** from https://nodejs.org (LTS version)
2. Double-click **`setup-and-build.bat`**
3. When done, find in the `dist\` folder:
   - **`ClockPro-Portable.exe`** — run anywhere, no install needed
   - **`ClockPro-Setup.exe`** — installs to your PC with Start Menu shortcut

## Features
- 🕐 Analog + digital clock (3D canvas-rendered)
- ⏰ Alarm manager with 12 sounds, math challenge, snooze
- ⏱ Stopwatch with lap tracking
- ⏳ Multiple timers + Pomodoro set
- 🌍 World clock for 26 cities
- 🔄 **Interval Timer** — 19 built-in templates (HIIT, Run/Walk, Tabata,
  Pomodoro, Box Breathing, Strength, Swim, Ladder…) + custom builder
  with live timeline preview, drag-reorder, and saved programs

## Requirements
- Windows 10 or 11 (64-bit)
- Node.js 18+ (only needed to build)
- Internet connection for first-time setup

## Project Structure
```
clock-pro-desktop/
├── main.js          Electron main process
├── preload.js       IPC bridge
├── index.html       App (self-contained HTML/CSS/JS)
├── package.json     Project config + build settings
├── assets/
│   ├── icon.png     App icon (PNG)
│   └── icon.ico     App icon (ICO for Windows)
├── setup-and-build.bat   Full build to .exe
└── run-dev.bat           Quick launch without building
```
